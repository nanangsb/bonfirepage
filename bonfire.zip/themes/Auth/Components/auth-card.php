<div class="card col-lg-5 col-md-7 shadow-lg" style="background-color: rgba(255,255,255,0.92)">
    <?= $slot ?>
</div>