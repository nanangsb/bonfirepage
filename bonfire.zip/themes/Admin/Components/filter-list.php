<div class="col-auto" x-cloak x-show="filtered" x-transition.duration.240ms>
    <?= $slot ?>
</div>
