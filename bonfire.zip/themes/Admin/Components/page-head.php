<div class="page-head mt-3 mb-4">
    <?= $slot ?? '' ?>
</div>
