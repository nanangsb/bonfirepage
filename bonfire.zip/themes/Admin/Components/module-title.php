<p class="m-0 p-0 fs-6 text-black-50">
    <?= $slot ?? '' ?>
</p>
