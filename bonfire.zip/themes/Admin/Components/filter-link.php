<div class="d-flex justify-content-end">
    <a href="#" x-on:click="filtered = ! filtered"><?= lang('Bonfire.filter' )?></a>
</div>
