<div class="bg-white p-2 p-sm-4 mb-5 border rounded-3 shadow-sm">
    <?= $slot ?>
</div>
